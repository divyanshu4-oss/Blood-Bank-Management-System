# Blood Bank Management System

Blood Bank Management System (BBMS) is designed to maintain all the information about blood donors, different blood groups available in each blood bank, and help them manage in a better way.

## Installing

* To RUN the program just download the zip file and run 'main.py'.
* Default Admin username='admin' and password='12345'.
* But to login as a user you have to first SignUp to fill his/her credentials then he/she can login into the application through the registered usernname and password.

## Built With
 * Tkinter(python's GUI toolkit).
 * SQLite with DB Browser.
