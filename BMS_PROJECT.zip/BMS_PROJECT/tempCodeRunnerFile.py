alex.forward(50)
# alex.write("South")